chmod +x start.sh 
